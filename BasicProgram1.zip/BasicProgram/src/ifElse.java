public class ifElse {
    public static void main(String[] args) {
        int x = 10;
        if(x % 2 == 0){
            System.out.println(x + " is even.");
        }else{
            System.out.println(x + " is odd.");
        }
        System.out.println("Hardwork is better than smart work");
    }
}
