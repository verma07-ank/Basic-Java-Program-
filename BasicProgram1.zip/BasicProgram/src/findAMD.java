public class findAMD {
    public static void main(String[] args) {
        int x = 10;
        int y = 15;
        int sum = x + y;
        System.out.println("sum of " + x + " and " + y + " : " + sum);
        int product = x * y;
        System.out.println("product of " + x + " and " + y + " : " + product);
        int v1 = x/y;
        int v2 = y/x;
        int v3 = x % y;
        System.out.println(v1);
        System.out.println(v2);
        System.out.println(v3);
    }
}
