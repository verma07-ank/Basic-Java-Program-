public class benjaminBulbs {
    public static void main(String[] args) {

    }
}
